<?php

return [
    'address'      => 'Adresse',
    'contact'      => 'Kontakt',
    'street'       => 'Straße',
    'rt'           => 'RT',
    'rw'           => 'RW',
    'village'      => 'Ort',
    'district'     => 'Ortsteil',
    'municipality' => 'Gemeinde',
    'city'         => 'Stadt',
    'province'     => 'Bundesland',
];

<?php

return [
    'lang'           => 'Sprache',
    'switch_tooltip' => 'Sprache wechseln zu :lang',
    'en'             => 'Englisch',
    'id'             => 'Indonesisch',
    'de'             => 'Deutsch',
];

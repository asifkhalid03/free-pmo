<?php

return [
    'address'      => 'Address',
    'contact'      => 'Contact',
    'street'       => 'Steet',
    'rt'           => 'RT',
    'rw'           => 'RW',
    'village'      => 'Village',
    'district'     => 'District',
    'municipality' => 'Municipality',
    'city'         => 'City',
    'province'     => 'Province',
];

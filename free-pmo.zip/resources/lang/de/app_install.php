<?php

return [
    'header'           => 'Install <span class="text-primary">'.config('app.name').'</span>',
    'agency_info_text' => 'Bitte füllen Sie das nachfolgende Fomular aus, um Ihre Agentur anzulegen.',
    'admin_info_text'  => 'Bitte füllen Sie das nachfolgende Formular aus, um einen Administrator Account anzulegen.',
    'admin_name'       => 'Administrator Name',
    'admin_email'      => 'Administrator E-Mail',
    'button'           => 'installiere jetzt Free PMO',
];

<?php

return [
    'lang'           => 'Bahasa',
    'switch_tooltip' => 'Ubah bahasa ke :lang',
    'en'             => 'Inggris',
    'id'             => 'Indonesia',
    'de'             => 'Jerman',
];

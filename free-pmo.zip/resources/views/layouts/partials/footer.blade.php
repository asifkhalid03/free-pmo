<footer class="footer" id="footer">
    <div id="copy" class="hidden-print">
         <a href="{{ url('https://hypersoftx.com') }}" target="_blank">

            Hyper Softx Project Management Panel

        </a>


    </div>
    {{-- Free PMO is an opensource software you are free to remove this footer text or section. --}}
</footer>

<?php

return [
    // Labels
    'list'      => 'Einstellungen',
    'create'    => 'neue Option hinzufügen',
    'created'   => 'Neue Option erstellt.',
    'updated'   => 'Option aktualisiert.',
    'delete'    => 'Option löschen',
    'deleted'   => 'Option gelöscht.',
    'undeleted' => 'Option kann nicht gelöscht werden.',
    'key'       => 'Schlüssel',
    'value'     => 'Wert',

    // Keys
    'money_sign'         => 'Geldsignatur',
    'money_sign_in_word' => 'Money Sign in Word',
];

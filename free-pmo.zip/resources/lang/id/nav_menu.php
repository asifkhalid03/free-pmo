<?php

return [
    'dashboard' => 'Dashboard',
    'agency'    => 'Profil Agensi',
    'calendar'  => 'Kalender',
    'nav'       => 'Backup/Restore DB',
];

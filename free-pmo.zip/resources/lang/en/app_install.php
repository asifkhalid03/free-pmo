<?php

return [
    'header'           => 'Install <span class="text-primary">'.config('app.name').'</span>',
    'agency_info_text' => 'Please fill form below to create your Agency.',
    'admin_info_text'  => 'Please fill form below to create an Administrator Account.',
    'admin_name'       => 'Administrator Name',
    'admin_email'      => 'Administrator Email',
    'button'           => 'Install Free PMO',
];

<?php

return [
    'project_status_stats'             => 'Projektstatus Satistik',
    'earnings_stats'                   => 'Verdienst Statistik',
    'upcoming_subscriptions_expiry'    => 'kommende auslaufende Abonnement',
    'no_upcoming_subscriptions_expiry' => 'Keine kommende auslaufende Abonnements in den nächsten 60 Tagen.',
    'yearly_earnings'                  => 'jährliche Verdienste',
    'finished_projects_count'          => 'abgeschlossene Projekte',
    'receiveable_earnings'             => 'empfangbare Verdienste',
];

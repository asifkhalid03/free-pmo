<?php

return [
    'dashboard' => 'Dashboard',
    'agency'    => 'Agency Profile',
    'calendar'  => 'Calendar',
    'nav'       => 'Backup/Restore DB',
];

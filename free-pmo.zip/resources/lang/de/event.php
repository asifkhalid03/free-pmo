<?php

return [
    'created'     => 'Event created.',
    'edit'        => 'Edit Events',
    'updated'     => 'Event updated.',
    'deleted'     => 'Event deleted.',
    'rescheduled' => 'Event has been rescheduled.',
];

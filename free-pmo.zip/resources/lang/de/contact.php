<?php

return [
    'contact'   => 'Kontakt',
    'phone'     => 'Telefon',
    'phone_abb' => 'Tel.',
    'cellphone' => 'Handy',
    'email'     => 'E-Mail',
    'website'   => 'Webseite',
];

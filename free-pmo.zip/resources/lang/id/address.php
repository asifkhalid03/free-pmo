<?php

return [
    'address'      => 'Alamat',
    'contact'      => 'Kontak',
    'street'       => 'Jalan',
    'rt'           => 'RT',
    'rw'           => 'RW',
    'village'      => 'Kelurahan/Desa',
    'district'     => 'Kecamatan',
    'municipality' => 'Kota/Kab.',
    'city'         => 'Kota',
    'province'     => 'Propinsi',
];

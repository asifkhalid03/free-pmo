<?php

return [
    'header'           => 'Install <span class="text-primary">'.config('app.name').'</span>',
    'agency_info_text' => 'Silakan isi formulir di bawah ini untuk membuat Agensi.',
    'admin_info_text'  => 'Silakan isi formulir di bawah ini untuk membuat akun Administrator.',
    'admin_name'       => 'Nama Administrator',
    'admin_email'      => 'Email Administrator',
    'button'           => 'Install Free PMO',
];

<?php

namespace App\Exceptions;

/**
 * Reference Key Not Found Exception.
 *
 * @author Nafies Luthfi <nafiesL@gmail.com>
 */
class ReferenceKeyNotFoundException extends \RuntimeException
{
}

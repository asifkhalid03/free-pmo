<?php

return [
    'contact'   => 'Contact',
    'phone'     => 'Phone',
    'phone_abb' => 'Phone',
    'cellphone' => 'Cell phone',
    'email'     => 'Email',
    'website'   => 'Website',
];

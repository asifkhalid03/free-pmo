<?php

return [
    'project_status_stats'             => 'Project Status Stat',
    'earnings_stats'                   => 'Earning Stat',
    'upcoming_subscriptions_expiry'    => 'Upcoming Subscription Expiry',
    'no_upcoming_subscriptions_expiry' => 'No upcoming expiry within next 60 days.',
    'yearly_earnings'                  => 'Yearly Earnings',
    'finished_projects_count'          => 'Finished projects',
    'receiveable_earnings'             => 'Receiveable Earnings',
];

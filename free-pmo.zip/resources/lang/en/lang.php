<?php

return [
    'lang'           => 'Language',
    'switch_tooltip' => 'Switch language to :lang',
    'en'             => 'English',
    'id'             => 'Bahasa',
    'de'             => 'German',
];

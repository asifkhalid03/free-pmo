<?php

return [
    'contact'   => 'Kontak',
    'phone'     => 'Telepon',
    'phone_abb' => 'Telp.',
    'cellphone' => 'Telepon Selular',
    'email'     => 'Email',
    'website'   => 'Website',
];

<?php

return [
    'created'     => 'Event berhasil diinput.',
    'edit'        => 'Edit Event',
    'updated'     => 'Event berhasil diupdate.',
    'deleted'     => 'Event berhasil dihapus.',
    'rescheduled' => 'Jadwal event berhasil diubah.',
];

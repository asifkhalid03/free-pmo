<?php

return [
    'dashboard' => 'Dashboard',
    'agency'    => 'Agenturprofil',
    'calendar'  => 'Kalender',
    'nav'       => 'DB Backup/Wiederherstellung',
];

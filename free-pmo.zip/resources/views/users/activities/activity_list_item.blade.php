<li class="list-group-item">
    <span class="label label-info pull-right">{{ $time }}</span>
    {{ $body }}
</li>
